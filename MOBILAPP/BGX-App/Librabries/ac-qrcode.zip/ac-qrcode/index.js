/**
 * Created by marno on 2017/4/10
 * Function: 入口类
 * Desc:
 */

import QRScannerView from './QRScanner';

export {QRScannerView}
